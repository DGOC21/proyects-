﻿using Microsoft.AspNetCore.Mvc;
using ProyectoMenu.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Net.WebSockets;

namespace ProyectoMenu.Controllers
{
    public class LoginController : Controller
    {
        private readonly MenuContext _context;

        public LoginController(MenuContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            List<Menu> menulista = _context.Menus.Include(m => m.InverseIdMenuPadreNavigation)
                .Where(m => m.IdMenuPadre == null).ToList();

            var options = new JsonSerializerOptions
            {
                ReferenceHandler = ReferenceHandler.IgnoreCycles,
                WriteIndented = true,
            };

            HttpContext.Session.SetString("menu", JsonSerializer.Serialize(menulista, options));

            return View();
        }
    }
}