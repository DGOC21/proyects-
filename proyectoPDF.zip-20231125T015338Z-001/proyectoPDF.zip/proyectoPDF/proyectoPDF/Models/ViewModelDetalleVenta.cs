﻿namespace proyectoPDF.Models
{
    public class ViewModelDetalleVenta
    {
        public string producto { get; set; }
        public string cantidad { get; set; }
        public string precio { get; set; }
        public string total { get; set; }

    }
}
