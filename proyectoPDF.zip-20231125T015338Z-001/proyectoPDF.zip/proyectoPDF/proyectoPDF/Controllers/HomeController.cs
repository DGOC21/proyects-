﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Scaffolding.Metadata;
using proyectoPDF.Models;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Rotativa.AspNetCore;
using proyectoPDF.Models.ViewModels;
using proyectopdf.Models;

namespace proyectoPDF.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;
        private readonly DBPDFContext dbpdfContext;

        public HomeController(DBPDFContext _context)
        {
            dbpdfContext = _context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult ImprimirVenta(int idVenta)
        {
            ViewModelVenta modelo = dbpdfContext.Venta.Include(Dv => Dv.DetalleVenta).Where(V => V.Id == idVenta).Select(v => new ViewModelVenta()
            {
                numeroVenta = v.NumeroVenta,
                documentoCliente = v.DocumentoCliente,
                nombreCliente = v.NombreCliente,
                subTotal = v.SubTotal.ToString(),
                impuesto = v.ImpuestoTotal.ToString(),
                total = v.Total.ToString(),
                detalleVenta = v.DetalleVenta.Select(Dv => new ViewModelDetalleVenta()
                {
                    producto = v.nombreProducto,
                    cantidad = Dv.Cantidad.ToString(),
                    precio = Dv.Precio.ToString(),
                    total = Dv.Total.ToString(),
                }).ToList()
            }).FirstOrDefault();
            return new ViewAsPdf("ImprimirVenta", modelo)
            {
                FileName = $"Venta {modelo.numeroVenta}.pdf",
                PageOrientation = Rotativa.AspNetCore.Options.Orientation.Portrait,
                PageSize = Rotativa.AspNetCore.Options.Size.A4
   
            };
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}