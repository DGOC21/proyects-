﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3.CSD
{
    internal class Convertir
    {
        public string NumeroToLetras (ulong numero)
        {
            string Respuesta; //Respuesta al servicio web para que haga conversion
            ServiceReference1.NumberConversionSoapTypeClient oconvnum = new ServiceReference1.NumberConversionSoapTypeClient("NumberConversionSoap"); //Creando objeto del servicio web, ConversionNumerica representa al servicio web

            Respuesta = oconvnum.NumberToWords(numero); //Se llama al método de interés, en este caso NumberToWords, colocando el argumento "Numero"

            return Respuesta; //Se envia la respuesta al servidor
        }

        public string NumeroToDolares (decimal Numero)
        {
            string Respues;
            ServiceReference1.NumberConversionSoapTypeClient oconvnum = new ServiceReference1.NumberConversionSoapTypeClient("NumberConversionSoap");
            Respues = oconvnum.NumberToDollars(Numero);
            return Respues;

        }
    }
}
